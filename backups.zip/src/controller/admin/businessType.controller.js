const responseConstants = require('../../constants/response.constatnts');
const statusCodes = require('../../constants/httpConstants');
const businessTypeModel = require('../../service/admin/businessType.service');
const businessTypeValidation = require('../../validation/admin/businessType.validation');

class businessTypeAdminController {
  list = async (request, response, nextFunction) => {
    try {
      const result = await businessTypeModel.list(request.query);
      return responseConstants.success(response, 'Business types fetched', result, statusCodes.OK);
    } catch (error) {
      nextFunction(error);
    }
  };

  create = async (request, response, nextFunction) => {
    try {
      const { error, value } = businessTypeValidation.ValidateCreate(request.body);
      const validationError = responseConstants.validatIonError(response, error);
      if (validationError) return;
      const category = await businessTypeModel.create({ adminId: request.auth._id, body: value, req: request });
      return responseConstants.success(response, 'Business type created', category, statusCodes.CREATED);
    } catch (error) {
      if (error instanceof businessTypeModel.BusinessTypeError) {
        return responseConstants.BadRequest(response, error.message, null, error.statusCode);
      }
      nextFunction(error);
    }
  };

  update = async (request, response, nextFunction) => {
    try {
        const { error, value } =
            businessTypeValidation.ValidateUpdate(request.body);

        const validationError =
            responseConstants.validatIonError(response, error);

        if (validationError) return;

        const businessType = await businessTypeModel.update({
            adminId: request.auth._id,
            businessTypeId: request.params.id,
            body: value,
            req: request,
        });

        return responseConstants.success(
            response,
            'Business type updated successfully',
            businessType,
            statusCodes.OK
        );
    } catch (error) {
        if (error instanceof businessTypeModel.BusinessTypeError) {
            return responseConstants.BadRequest(
                response,
                error.message,
                null,
                error.statusCode
            );
        }

        nextFunction(error);
    }
};

  remove = async (request, response, nextFunction) => {
    try {
      const result = await businessTypeModel.remove({ adminId: request.auth._id, categoryId: request.params.id, req: request });
      return responseConstants.success(response, 'Business type deleted', result, statusCodes.OK);
    } catch (error) {
      if (error instanceof businessTypeModel.BusinessTypeError) {
        return responseConstants.BadRequest(response, error.message, null, error.statusCode);
      }
      nextFunction(error);
    }
  };
}

module.exports = new businessTypeAdminController();
