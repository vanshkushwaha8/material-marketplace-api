const mongoose = require('mongoose');
const businessTypeSchema = require('../schema/businessTypeSchema');
const businessTypeModel = mongoose.model('business_type', businessTypeSchema);
module.exports = businessTypeModel;
