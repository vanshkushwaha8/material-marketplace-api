const mongoose = require('mongoose');
const deleteConstants = require('../constants/delete.constants');
const STORE_VERIFICATION_STATES = require('../constants/storeVerification.constants');
const storeCategorySchema = new mongoose.Schema(
    {
        name: {
            type: String,
            required: true,
            trim: true,
            unique: true,
        },
        verificationStatus: {
            type: String,

            enum: Object.values(
                STORE_VERIFICATION_STATES
            ),

            default:
                STORE_VERIFICATION_STATES.UNVERIFIED,

            index: true,
        },

        is_deleted: {
            type: String,
            enum: [
                deleteConstants.NOT_DELETED,
                deleteConstants.DELETED,
            ],
            default: deleteConstants.NOT_DELETED,
            index: true,
        },
    },
    {
        timestamps: true,
    }
);

// Supports filtering deleted records + alphabetical sorting
storeCategorySchema.index({
    is_deleted: 1,
    name: 1,
});

module.exports = storeCategorySchema;
