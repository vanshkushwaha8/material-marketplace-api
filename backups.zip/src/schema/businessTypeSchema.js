const mongoose = require('mongoose');
const deleteConstants = require('../constants/delete.constants');

const businessTypeSchema = new mongoose.Schema(
    {
        name: {
            type: String,
            required: true,
            trim: true,
            unique: true,
        },

        is_deleted: {
            type: String,
            enum: [
                deleteConstants.NOT_DELETED,
                deleteConstants.DELETED,
            ],
            default: deleteConstants.NOT_DELETED,
            index: true,
        },
    },
    {
        timestamps: true,
    }
);

module.exports = businessTypeSchema;