const storeCategoryModel =require('../../model/storeCategory.model');

const deleteConstants = require('../../constants/delete.constants');


async function list() {

    return storeCategoryModel.aggregate([

        {
            $match: {
                is_deleted:
                    deleteConstants.NOT_DELETED,
            },
        },

        {
            $sort: {
                name: 1,
            },
        },

        {
            $project: {
                _id: 1,
                name: 1,
            },
        },

    ]);
}


module.exports = {
    list,
};