const businessTypeModel = require('../../model/businessType.model');

const deleteConstants = require('../../constants/delete.constants');

// Public, read-only — sellers browse available business types
// during registration. Management lives in the admin-side service.

async function list() {
    return businessTypeModel.aggregate([
        {
            $match: {
                is_deleted: deleteConstants.NOT_DELETED,
            },
        },
        {
            $sort: {
                name: 1,
            },
        },
    ]);
}

module.exports = { list };