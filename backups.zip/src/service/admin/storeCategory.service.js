const mongoose = require('mongoose');

const storeCategoryModel =
    require('../../model/storeCategory.model');

const deleteConstants =
    require('../../constants/delete.constants');

const {
    createAuditLogAdmin,
} = require('../../helper/audit.helper');

const auditLogConstants =
    require('../../constants/auditLogConstants');


class StoreCategoryError extends Error {

    constructor(message, statusCode = 400) {
        super(message);

        this.name = 'StoreCategoryError';
        this.statusCode = statusCode;
    }
}


/**
 * CREATE STORE CATEGORY
 */
async function create({ adminId, body, req }) {

    const existing =
        await storeCategoryModel.findOne({
            name: body.name,
            is_deleted:
                deleteConstants.NOT_DELETED,
        });

    if (existing) {
        throw new StoreCategoryError(
            'A store category with this name already exists',
            409
        );
    }

    const storeCategory =
        await storeCategoryModel.create({
            name: body.name,
        });

    await createAuditLogAdmin({
        req,
        adminId,
        action:
            auditLogConstants.STORE_CATEGORY_CREATED,
        entity: 'store_categories',
        entityId: storeCategory._id,
    });

    return storeCategory;
}


/**
 * UPDATE STORE CATEGORY
 */
async function update({
    adminId,
    storeCategoryId,
    body,
    req,
}) {

    if (
        !mongoose.Types.ObjectId.isValid(
            storeCategoryId
        )
    ) {
        throw new StoreCategoryError(
            'Invalid store category id'
        );
    }

    const storeCategory =
        await storeCategoryModel.findOne({
            _id: storeCategoryId,
            is_deleted:
                deleteConstants.NOT_DELETED,
        });

    if (!storeCategory) {
        throw new StoreCategoryError(
            'Store category not found',
            404
        );
    }

    if (
        body.name &&
        body.name !== storeCategory.name
    ) {

        const existing =
            await storeCategoryModel.findOne({
                name: body.name,

                _id: {
                    $ne: storeCategoryId,
                },

                is_deleted:
                    deleteConstants.NOT_DELETED,
            });

        if (existing) {
            throw new StoreCategoryError(
                'A store category with this name already exists',
                409
            );
        }
    }

    if (body.name !== undefined) {
        storeCategory.name = body.name;
    }

    await storeCategory.save();

    await createAuditLogAdmin({
        req,
        adminId,
        action:
            auditLogConstants.STORE_CATEGORY_UPDATED,
        entity: 'store_categories',
        entityId: storeCategory._id,
    });

    return storeCategory;
}


/**
 * SOFT DELETE STORE CATEGORY
 */
async function remove({
    adminId,
    storeCategoryId,
    req,
}) {

    if (
        !mongoose.Types.ObjectId.isValid(
            storeCategoryId
        )
    ) {
        throw new StoreCategoryError(
            'Invalid store category id'
        );
    }

    const storeCategory =
        await storeCategoryModel.findOneAndUpdate(
            {
                _id: storeCategoryId,
                is_deleted:
                    deleteConstants.NOT_DELETED,
            },
            {
                is_deleted:
                    deleteConstants.DELETED,
            },
            {
                new: true,
            }
        );

    if (!storeCategory) {
        throw new StoreCategoryError(
            'Store category not found',
            404
        );
    }

    await createAuditLogAdmin({
        req,
        adminId,
        action:
            auditLogConstants.STORE_CATEGORY_DELETED,
        entity: 'store_categories',
        entityId: storeCategory._id,
    });

    return {
        deleted: true,
    };
}


/**
 * ADMIN LIST
 *
 * MongoDB aggregation + facet pagination
 */
async function list({
    page = 1,
    limit = 50,
} = {}) {

    const pageNum =
        Math.max(1, Number(page) || 1);

    const pageLimit =
        Math.min(
            200,
            Math.max(1, Number(limit) || 50)
        );

    const pipeline = [

        {
            $match: {
                is_deleted:
                    deleteConstants.NOT_DELETED,
            },
        },

        {
            $sort: {
                name: 1,
            },
        },

        {
            $facet: {

                getData: [
                    {
                        $skip:
                            (pageNum - 1) *
                            pageLimit,
                    },

                    {
                        $limit: pageLimit,
                    },
                ],

                count: [
                    {
                        $count: 'total',
                    },
                ],
            },
        },
    ];

    const [result] =
        await storeCategoryModel.aggregate(
            pipeline
        );

    const getData =
        result?.getData || [];

    const count =
        result?.count?.[0]?.total || 0;

    return {
        getData,
        count,
        page: pageNum,
        limit: pageLimit,
    };
}


module.exports = {
    StoreCategoryError,
    create,
    update,
    remove,
    list,
};