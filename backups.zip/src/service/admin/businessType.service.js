
const mongoose = require('mongoose');

const businessTypeModel = require('../../model/businessType.model');

const deleteConstants = require('../../constants/delete.constants');

const { createAuditLogAdmin } = require('../../helper/audit.helper');

const auditLogConstants = require('../../constants/auditLogConstants');

class BusinessTypeError extends Error {
    constructor(message, statusCode = 400) {
        super(message);
        this.name = 'BusinessTypeError';
        this.statusCode = statusCode;
    }
}


async function create({ adminId, body, req }) {
    const existing = await businessTypeModel.findOne({
        name: body.name,
        is_deleted: deleteConstants.NOT_DELETED,
    });

    if (existing) {
        throw new BusinessTypeError(
            'A business type with this name already exists',
            409
        );
    }

    const businessType = await businessTypeModel.create({
        name: body.name,
    });

    await createAuditLogAdmin({
        req,
        adminId,
        action: auditLogConstants.BUSINESS_TYPE_CREATED,
        entity: 'business_types',
        entityId: businessType._id,
    });

    return businessType;
}


async function update({ adminId, businessTypeId, body, req }) {
    if (!mongoose.Types.ObjectId.isValid(businessTypeId)) {
        throw new BusinessTypeError('Invalid business type id');
    }

    const businessType = await businessTypeModel.findOne({
        _id: businessTypeId,
        is_deleted: deleteConstants.NOT_DELETED,
    });

    if (!businessType) {
        throw new BusinessTypeError('Business type not found', 404);
    }

    if (body.name && body.name !== businessType.name) {
        const existing = await businessTypeModel.findOne({
            name: body.name,
            _id: { $ne: businessTypeId },
            is_deleted: deleteConstants.NOT_DELETED,
        });

        if (existing) {
            throw new BusinessTypeError(
                'A business type with this name already exists',
                409
            );
        }
    }

    if (body.name !== undefined) {
        businessType.name = body.name;
    }

    await businessType.save();

    await createAuditLogAdmin({
        req,
        adminId,
        action: auditLogConstants.BUSINESS_TYPE_UPDATED,
        entity: 'business_types',
        entityId: businessType._id,
    });

    return businessType;
}
/**
 * Soft Delete Business Type
 */
async function remove({ adminId, businessTypeId, req }) {
    if (!mongoose.Types.ObjectId.isValid(businessTypeId)) {
        throw new BusinessTypeError('Invalid business type id');
    }

    const businessType = await businessTypeModel.findOneAndUpdate(
        {
            _id: businessTypeId,
            is_deleted: deleteConstants.NOT_DELETED,
        },
        {
            is_deleted: deleteConstants.DELETED,
        },
        {
            new: true,
        }
    );

    if (!businessType) {
        throw new BusinessTypeError('Business type not found', 404);
    }

    await createAuditLogAdmin({
        req,
        adminId,
        action: auditLogConstants.BUSINESS_TYPE_DELETED,
        entity: 'business_types',
        entityId: businessType._id,
    });

    return {
        deleted: true,
        businessType,
    };
}

/**
 * List Business Types
 */
async function list({ page = 1, limit = 50 } = {}) {
    const pageNum = Math.max(1, Number(page) || 1);
    const pageLimit = Math.min(200, Math.max(1, Number(limit) || 50));

    const pipeline = [
        {
            $match: {
                is_deleted: deleteConstants.NOT_DELETED,
            },
        },

        {
            $sort: {
                name: 1,
            },
        },

        {
            $facet: {
                getData: [
                    {
                        $skip: (pageNum - 1) * pageLimit,
                    },
                    {
                        $limit: pageLimit,
                    },
                ],

                count: [
                    {
                        $count: 'total',
                    },
                ],
            },
        },
    ];

    const [result] = await businessTypeModel.aggregate(pipeline);

    const getData = result?.getData || [];
    const count = result?.count?.[0]?.total || 0;

    return {
        getData,
        count,
        page: pageNum,
        limit: pageLimit,
    };
}

module.exports = {
    BusinessTypeError,
    create,
    update,
    remove,
    list,
};

