
const Joi = require('joi');

class businessTypeValidation {

    static create() {
        return Joi.object({
            name: Joi.string()
                .trim()
                .min(2)
                .max(100)
                .required()
                .messages({
                    'string.empty': 'Business type name is required',
                    'string.min': 'Business type name must be at least 2 characters',
                    'string.max': 'Business type name cannot exceed 100 characters',
                    'any.required': 'Business type name is required',
                }),
        });
    }

    static update() {
        return this.create().fork(
            ['name'],
            (schema) => schema.optional()
        );
    }

    static ValidateCreate(data) {
        return this.create().validate(data, {
            abortEarly: false,
            stripUnknown: true,
        });
    }

    static ValidateUpdate(data) {
        return this.update().validate(data, {
            abortEarly: false,
            stripUnknown: true,
        });
    }
}

module.exports = businessTypeValidation;

