const Joi = require('joi');

class storeCategoryValidation {

    static create() {
        return Joi.object({
            name: Joi.string()
                .trim()
                .min(2)
                .max(100)
                .required()
                .messages({
                    'string.empty':
                        'Store category name is required',

                    'string.min':
                        'Store category name must be at least 2 characters',

                    'string.max':
                        'Store category name cannot exceed 100 characters',

                    'any.required':
                        'Store category name is required',
                }),
        });
    }

    static update() {
        return this.create().fork(
            ['name'],
            (schema) => schema.optional()
        );
    }

    static ValidateCreate(data) {
        return this.create().validate(data, {
            abortEarly: false,
            stripUnknown: true,
        });
    }

    static ValidateUpdate(data) {
        return this.update().validate(data, {
            abortEarly: false,
            stripUnknown: true,
        });
    }
}

module.exports = storeCategoryValidation;