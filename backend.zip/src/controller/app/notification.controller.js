const responseConstants = require('../../constants/response.constatnts');
const statusCodes = require('../../constants/httpConstants');
const notificationService = require('../../service/app/notification.service');

class NotificationController {
  list = async (request, response, nextFunction) => {
    try {
      const result = await notificationService.listForUser({ userId: request.auth._id, page: request.query.page, limit: request.query.limit, unreadOnly: request.query.unreadOnly === 'true' });
      return responseConstants.success(response, 'Notifications fetched', result, statusCodes.OK);
    } catch (error) { nextFunction(error); }
  };

  unreadCount = async (request, response, nextFunction) => {
    try {
      const count = await notificationService.getUnreadCount(request.auth._id);
      return responseConstants.success(response, 'Unread count fetched', { count }, statusCodes.OK);
    } catch (error) { nextFunction(error); }
  };

  markRead = async (request, response, nextFunction) => {
    try {
      const notification = await notificationService.markAsRead({ notificationId: request.params.id, userId: request.auth._id });
      if (!notification) return responseConstants.BadRequest(response, 'Notification not found', null, statusCodes.NOT_FOUND);
      return responseConstants.success(response, 'Marked as read', notification, statusCodes.OK);
    } catch (error) { nextFunction(error); }
  };

  markAllRead = async (request, response, nextFunction) => {
    try {
      const result = await notificationService.markAllAsRead(request.auth._id);
      return responseConstants.success(response, 'All marked as read', result, statusCodes.OK);
    } catch (error) { nextFunction(error); }
  };
}
module.exports = new NotificationController();