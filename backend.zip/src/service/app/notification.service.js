const notificationModel = require('../../model/notification.model');
const mongoose = require('mongoose');

// The single creation point every business event calls into — never
// insert into notificationModel directly from elsewhere, so notification
// shape stays consistent everywhere it's triggered from.
async function createNotification({ recipientId, type, title, message, entityType = null, entityId = null }) {
  if (!recipientId) return null; // e.g. system-only events with no user to notify
  return notificationModel.create({ recipient: recipientId, type, title, message, entityType, entityId }).catch((err) => {
    console.error('Notification creation failed:', err.message, '| Type:', type);
    return null; // a failed notification must never break the business action that triggered it
  });
}

async function listForUser({ userId, page = 1, limit = 20, unreadOnly = false }) {
  const query = { recipient: userId };
  if (unreadOnly) query.isRead = false;
  const pageNum = Math.max(1, Number(page) || 1);
  const pageLimit = Math.min(100, Number(limit) || 20);
  const [getData, count] = await Promise.all([
    notificationModel.find(query).sort({ createdAt: -1 }).skip((pageNum - 1) * pageLimit).limit(pageLimit).lean(),
    notificationModel.countDocuments(query),
  ]);
  return { getData, count, page: pageNum, limit: pageLimit };
}

async function getUnreadCount(userId) {
  return notificationModel.countDocuments({ recipient: userId, isRead: false });
}

async function markAsRead({ notificationId, userId }) {
  if (!mongoose.Types.ObjectId.isValid(notificationId)) return null;
  return notificationModel.findOneAndUpdate(
    { _id: notificationId, recipient: userId },
    { $set: { isRead: true, readAt: new Date() } },
    { new: true }
  );
}

async function markAllAsRead(userId) {
  const result = await notificationModel.updateMany({ recipient: userId, isRead: false }, { $set: { isRead: true, readAt: new Date() } });
  return { modified: result.modifiedCount };
}

module.exports = { createNotification, listForUser, getUnreadCount, markAsRead, markAllAsRead };